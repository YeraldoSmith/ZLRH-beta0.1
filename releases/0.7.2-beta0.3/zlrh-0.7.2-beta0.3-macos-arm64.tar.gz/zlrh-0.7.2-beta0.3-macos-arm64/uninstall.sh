#!/bin/sh
# ZLangRH（zlrh）卸载脚本 —— macOS / Linux
# 默认只删除 zlrh 程序本身；工作目录 ~/.zlrh（Python 环境、日志、排行榜、协议同意记录）会先询问再删除。
# 你自己的模型、数据、运行目录（models/ runs/ 等）一律不会被动到。
set -eu

DEST_DIR="${ZLRH_INSTALL_DIR:-${HOME}/.local/bin}"
DEST="${DEST_DIR}/zlrh"
HOME_DIR="${ZLRH_HOME:-${HOME}/.zlrh}"

if [ -f "${DEST}" ]; then
  rm -f "${DEST}"
  echo "✔ 已删除 ${DEST}"
else
  echo "没有在 ${DEST} 找到 zlrh（如果安装时改过位置，请设置 ZLRH_INSTALL_DIR 后重试）"
fi

if [ -d "${HOME_DIR}" ] && [ -t 0 ]; then
  printf '是否同时删除工作目录 %s（Python 虚拟环境、日志、排行榜等，不含你的模型）？[y/N] ' "${HOME_DIR}"
  read -r answer || answer="n"
  case "${answer}" in
    y|Y|yes|YES)
      # 为安全起见，只自动删除默认位置 ~/.zlrh；自定义的 ZLRH_HOME 请手动删除
      if [ "${HOME_DIR}" = "${HOME}/.zlrh" ] && [ -n "${HOME}" ] && [ "${HOME}" != "/" ]; then
        rm -rf "${HOME}/.zlrh" && echo "✔ 已删除 ${HOME}/.zlrh"
      else
        echo "为安全起见，只自动删除默认位置 ~/.zlrh；请手动删除 ${HOME_DIR}"
      fi
      ;;
    *) echo "保留 ${HOME_DIR}" ;;
  esac
fi
echo "如果安装时在 shell 配置文件里加过 PATH 设置（# ZLangRH (zlrh) 那一行），可以手动删除，留着也无害。"
