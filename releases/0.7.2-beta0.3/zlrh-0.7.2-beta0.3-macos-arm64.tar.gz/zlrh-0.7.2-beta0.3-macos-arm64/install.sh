#!/bin/sh
# ZLangRH（zlrh）安装脚本 —— macOS / Linux
#
# 做的事情（只有这些）：
#   1. 用安装包里的 SHA256SUMS 校验 zlrh 程序是否完整、未被改动；
#   2. 把 zlrh 复制到 ~/.local/bin（可用环境变量 ZLRH_INSTALL_DIR 改位置）；
#   3. macOS：去掉这一个文件的“来自互联网”隔离标记，避免被系统拦截；
#   4. 如果安装目录不在 PATH 里，征得你同意后在 shell 配置文件末尾追加一行 PATH 设置。
# 不需要、也不会使用 sudo；不会修改安装目录与 shell 配置文件以外的任何东西。
set -eu

HERE=$(cd "$(dirname "$0")" && pwd)
BIN="${HERE}/zlrh"
DEST_DIR="${ZLRH_INSTALL_DIR:-${HOME}/.local/bin}"
DEST="${DEST_DIR}/zlrh"

say() { printf '%s\n' "$*"; }
die() { printf '✘ %s\n' "$*" >&2; exit 1; }

say "== ZLangRH（zlrh）安装 =="
[ -f "${BIN}" ] || die "在 ${HERE} 里没有找到 zlrh 程序，请在解压后的目录中运行本脚本"

if [ "$(id -u)" = "0" ]; then
  say "⚠ 你正在以 root 运行。zlrh 不需要管理员权限，建议退出后用普通用户运行：sh install.sh"
fi

# 1. 校验完整性
if [ -f "${HERE}/SHA256SUMS" ]; then
  expected=$(grep ' zlrh$' "${HERE}/SHA256SUMS" | awk '{print $1}')
  if command -v shasum >/dev/null 2>&1; then
    actual=$(shasum -a 256 "${BIN}" | awk '{print $1}')
  elif command -v sha256sum >/dev/null 2>&1; then
    actual=$(sha256sum "${BIN}" | awk '{print $1}')
  else
    actual=""
  fi
  if [ -n "${actual}" ] && [ -n "${expected}" ]; then
    [ "${actual}" = "${expected}" ] || die "校验失败：zlrh 程序与发布时不一致（可能下载不完整或被改动），请重新下载"
    say "✔ 完整性校验通过（SHA-256 ${actual}）"
  else
    say "⚠ 跳过完整性校验（缺少 shasum / sha256sum 或校验文件）"
  fi
fi

# 2. 复制
mkdir -p "${DEST_DIR}"
cp "${BIN}" "${DEST}.tmp.$$"
chmod 755 "${DEST}.tmp.$$"
mv -f "${DEST}.tmp.$$" "${DEST}"

# 3. macOS 隔离标记（只针对刚安装的这一个文件）
if [ "$(uname -s)" = "Darwin" ]; then
  xattr -d com.apple.quarantine "${DEST}" 2>/dev/null || true
fi
say "✔ 已安装到 ${DEST}"

# 4. PATH
case ":${PATH}:" in
  *":${DEST_DIR}:"*) on_path=1 ;;
  *) on_path=0 ;;
esac
if [ "${on_path}" = "0" ]; then
  case "${SHELL:-}" in
    */zsh) rc="${HOME}/.zshrc" ;;
    */bash) if [ "$(uname -s)" = "Darwin" ]; then rc="${HOME}/.bash_profile"; else rc="${HOME}/.bashrc"; fi ;;
    *) rc="${HOME}/.profile" ;;
  esac
  line="export PATH=\"${DEST_DIR}:\${PATH}\""
  if [ -f "${rc}" ] && grep -qF "${line}" "${rc}"; then
    say "✔ ${rc} 中已有 PATH 设置"
  else
    answer="n"
    if [ -t 0 ]; then
      printf '是否把 %s 加入 PATH（在 %s 末尾追加一行）？[Y/n] ' "${DEST_DIR}" "${rc}"
      read -r answer || answer="n"
      [ -z "${answer}" ] && answer="y"
    fi
    case "${answer}" in
      y|Y|yes|YES)
        printf '\n# ZLangRH (zlrh)\n%s\n' "${line}" >> "${rc}"
        say "✔ 已写入 ${rc}，新开一个终端窗口后生效（或执行：source ${rc}）"
        ;;
      *)
        say "请手动把下面这行加入你的 shell 配置文件："
        say "  ${line}"
        ;;
    esac
  fi
fi

say ""
say "下一步："
say "  1. 新开一个终端窗口，运行  zlrh --version  确认安装成功"
say "  2. 运行  zlrh  —— 首次使用会显示《用户协议与版权声明》，阅读后输入「同意」"
say "  3. 详细步骤见同目录下的 INSTALL.md"
