# 版权声明 / Copyright

**ZLangRH（LLM-ZLangRH）**

Copyright © 2026 **Yeraldo Smith**

- GitHub：[YeraldoSmith](https://github.com/YeraldoSmith)
- Hugging Face：[Yeraldo](https://huggingface.co/Yeraldo)

本仓库的源代码、训练协议定义（`crates/zlrh-train/protocols/`）、能力技能包（`crates/zlrh-distill/skills/`）、
示例与文档的著作权归 Yeraldo Smith 所有。

项目参考了多个开源项目与论文的公开思路与算法，代码为本项目独立编写（详见 README 的“参考与致谢”）。
程序运行时调用的第三方软件（llama.cpp、MLX / mlx-lm、PyTorch、Transformers、PEFT 等）及其下载的模型、数据集，
其著作权与许可证归各自的作者所有。

## 授权（私人 Beta）

本项目目前为私人 Beta，**保留所有权利（All rights reserved）**，不是开源软件：
未经作者书面许可，不得复制、分发、出售、转授权或公开上传本软件及其任何部分。
程序首次运行时会显示《用户协议与版权声明》（全文见 `crates/zlrh-cli/assets/EULA.md`，安装包中为 `EULA.md`），
需要用户输入“同意”后才能使用；`zlrh license` 可随时查看，`zlrh license --revoke` 撤回同意。

## 第三方组件

编译进 `zlrh` 的开源组件（约 180 个 Rust crate）均为宽松许可证（MIT / Apache-2.0 / BSD / ISC / Zlib / Unicode 等），
另有一个未经修改的 MPL-2.0 组件（option-ext）。完整清单与许可证全文由 `scripts/third_party_licenses.py` 生成，
随每个安装包以 `THIRD_PARTY_LICENSES.txt` 发布。

