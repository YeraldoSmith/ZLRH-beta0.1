﻿# ZLangRH（zlrh）卸载脚本 —— Windows
# 只删除 zlrh.exe 与它的安装目录，并从当前用户 PATH 中移除；工作目录 %USERPROFILE%\.zlrh 会先询问。
$ErrorActionPreference = "Stop"
$destDir = if ($env:ZLRH_INSTALL_DIR) { $env:ZLRH_INSTALL_DIR } else { Join-Path $env:LOCALAPPDATA "Programs\zlrh" }
$dest = Join-Path $destDir "zlrh.exe"
if (Test-Path $dest) { Remove-Item -Force $dest; Write-Host "✔ 已删除 $dest" }
if ((Test-Path $destDir) -and -not (Get-ChildItem $destDir)) { Remove-Item $destDir }

$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($userPath) {
  $parts = $userPath -split ';' | Where-Object { $_ -and $_ -ne $destDir }
  [Environment]::SetEnvironmentVariable("Path", ($parts -join ';'), "User")
}

$home_dir = if ($env:ZLRH_HOME) { $env:ZLRH_HOME } else { Join-Path $env:USERPROFILE ".zlrh" }
if (Test-Path $home_dir) {
  # 环境变量 ZLRH_REMOVE_HOME=1/0 可跳过询问（用于自动化卸载）
  $answer = if ($env:ZLRH_REMOVE_HOME) { $env:ZLRH_REMOVE_HOME } else { Read-Host "是否同时删除工作目录 ${home_dir}（Python 环境、日志、排行榜等，不含你的模型）？[y/N]" }
  if ($answer -match '^(y|yes|1)$') {
    # 为安全起见，只自动删除默认位置 %USERPROFILE%\.zlrh；自定义的 ZLRH_HOME 请手动删除
    $default = Join-Path $env:USERPROFILE ".zlrh"
    if ($env:USERPROFILE -and ($home_dir.TrimEnd('\') -eq $default)) { Remove-Item -Recurse -Force $default; Write-Host "✔ 已删除 $default" }
    else { Write-Host "为安全起见，只自动删除默认位置 $default；请手动删除 ${home_dir}" }
  }
}
