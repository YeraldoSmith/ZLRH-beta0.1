﻿# ZLangRH（zlrh）安装脚本 —— Windows 10 / 11
# 用法：在解压后的文件夹里，右键“在终端中打开”，执行：
#   powershell -ExecutionPolicy Bypass -File .\install.ps1
# 做的事情：校验 zlrh.exe → 复制到 %LOCALAPPDATA%\Programs\zlrh → 解除“来自互联网”标记 → 加入当前用户的 PATH。
# 不需要管理员权限，不修改系统级设置。
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$bin = Join-Path $here "zlrh.exe"
$destDir = if ($env:ZLRH_INSTALL_DIR) { $env:ZLRH_INSTALL_DIR } else { Join-Path $env:LOCALAPPDATA "Programs\zlrh" }
$dest = Join-Path $destDir "zlrh.exe"

Write-Host "== ZLangRH（zlrh）安装 =="
if (-not (Test-Path $bin)) { throw "在 $here 里没有找到 zlrh.exe，请在解压后的文件夹中运行本脚本" }

$sums = Join-Path $here "SHA256SUMS"
if (Test-Path $sums) {
  $line = Get-Content $sums | Where-Object { $_ -match ' zlrh\.exe$' } | Select-Object -First 1
  if ($line) {
    $expected = ($line -split '\s+')[0].ToLower()
    $actual = (Get-FileHash -Algorithm SHA256 $bin).Hash.ToLower()
    if ($expected -ne $actual) { throw "校验失败：zlrh.exe 与发布时不一致（可能下载不完整或被改动），请重新下载" }
    Write-Host "✔ 完整性校验通过（SHA-256 ${actual}）"
  }
}

New-Item -ItemType Directory -Force -Path $destDir | Out-Null
Copy-Item -Force $bin $dest
Unblock-File -Path $dest
Write-Host "✔ 已安装到 $dest"

$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if (-not $userPath) { $userPath = "" }
if (($userPath -split ';') -notcontains $destDir) {
  # 环境变量 ZLRH_ADD_PATH=1/0 可跳过询问（用于自动化安装）
  $answer = if ($env:ZLRH_ADD_PATH) { $env:ZLRH_ADD_PATH } else { Read-Host "是否把 $destDir 加入当前用户的 PATH？[Y/n]" }
  if ($answer -eq "" -or $answer -match '^(y|yes|1)$') {
    $newPath = if ($userPath) { "$userPath;$destDir" } else { $destDir }
    [Environment]::SetEnvironmentVariable("Path", $newPath, "User")
    Write-Host "✔ 已加入 PATH，新开一个终端窗口后生效"
  } else {
    Write-Host "未修改 PATH，可以用完整路径运行：$dest"
  }
}

Write-Host ""
Write-Host "下一步："
Write-Host "  1. 新开一个终端窗口，运行  zlrh --version  确认安装成功"
Write-Host "  2. 运行  zlrh  —— 首次使用会显示《用户协议与版权声明》，阅读后输入「同意」"
Write-Host "  3. 详细步骤见同目录下的 INSTALL.md"
